using SeaEngine.Common;
using SeaEngine.GameDataManager;
using SeaEngine.GameDataManager.Components;

namespace SeaEngine.GameEffectManager.Effects.Charles;

[Effect]
// ReSharper disable once InconsistentNaming
public class Cl_N : IEffect
{
    //이동범위 내 적을 하나 선택해 공격합니다.
    //공격받은 적은 다음 턴 공격할 수 없습니다.
    public string Id => "Cl_N"; 

    public List<EffectTarget> GetTargets(Uid source, GameData data)
    {
        var card = data.GetCardById(source);
        return data.GetMoveArea(card)
            .Where(p => !data.Board.IsEmptyCell(p.Item1, p.Item2) && data.Board.GetCardByPos(p.Item1, p.Item2)!.Owner != card.Owner)
            .Select(p => EffectTarget.Unit(data.Board.GetCardByPos(p.Item1, p.Item2)!.Guid))
            .ToList();
    }

    public void Apply(Uid source, EffectTarget target, GameData data)
    {
        var zone = data.GetCardZoneById(source);
        var card = data.GetCardById(source);
        var owner = card.Owner;
        
        zone.RemoveCard(card);

        CombatUtils.Attack(card, data.GetCardById(target.Guid), data);
        var defender = data.GetCardById(target.Guid);
        if (defender.Unit.IsPlaced)
        {
            defender.Unit.AddOrRefreshStatus(UnitStatusType.AttackLock, 1, 2, $"effect:{Id}:lock");
        }
        
        owner.Trash.AddCard(card);
    }
}
