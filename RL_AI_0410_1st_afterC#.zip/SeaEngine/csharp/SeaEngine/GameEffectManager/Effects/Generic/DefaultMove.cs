using SeaEngine.Common;
using SeaEngine.GameDataManager;

namespace SeaEngine.GameEffectManager.Effects;

[Effect]
public class DefaultMove : IEffect
{
    public string Id => "DefaultMove";

    public List<EffectTarget> GetTargets(Uid source, GameData data)
    {
        var cur = data.Board.GetCardById(source);
        var targets = data.GetMoveArea(cur)
            .Where(v => data.Board.IsEmptyCell(v.Item1, v.Item2))
            .Select(v => EffectTarget.Cell(v.Item1, v.Item2)).ToList();
        return targets;
    }

    public void Apply(Uid source, EffectTarget target, GameData data)
    {
        //유효성 검사는 필요없음. GetTarget가 해줌.
        var cur = data.Board.GetCardById(source);
        cur.Unit.Move(target.PosX, target.PosY);
        cur.Unit.IsMoved = true;
        data.ApplyBasicMoveEvent(cur);
    }
}
