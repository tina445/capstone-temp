import json
from RL_AI.agents.agents import SeaEngineRandomAgent
from RL_AI.simulation.evaluator import play_evaluation_match

a1 = SeaEngineRandomAgent()
a2 = SeaEngineRandomAgent()
OR_DECK = '["Or_L", "Or_B", "Or_N", "Or_R", "Or_P", "Or_P", "Or_P"]'
CL_DECK = '["Cl_L", "Cl_B", "Cl_N", "Cl_R", "Cl_P", "Cl_P", "Cl_P"]'

w1, w2 = 0, 0
for i in range(100):
   res = play_evaluation_match(a1, a2, player1_deck=OR_DECK, player2_deck=CL_DECK)
   if res['snapshot']['result'] == 'Player1Win': w1 += 1
   elif res['snapshot']['result'] == 'Player2Win': w2 += 1

print(f'Random(P1,Orange) vs Random(P2,Clear): P1={w1}, P2={w2}')

w1, w2 = 0,0
for i in range(100):
   res = play_evaluation_match(a1, a2, player1_deck=CL_DECK, player2_deck=OR_DECK)
   if res['snapshot']['result'] == 'Player1Win': w1 += 1
   elif res['snapshot']['result'] == 'Player2Win': w2 += 1

print(f'Random(P1,Clear) vs Random(P2,Orange): P1={w1}, P2={w2}')
