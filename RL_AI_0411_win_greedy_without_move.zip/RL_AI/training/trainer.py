"""PPO trainer for SeaEngine-backed RL agents."""

from __future__ import annotations

from dataclasses import dataclass
import random
from typing import Callable, Dict, List, Optional, Sequence

import torch

from RL_AI.SeaEngine.action_adapter import choose_action_with_agent
from RL_AI.agents.agents import SeaEngineAgent, SeaEngineGreedyAgent, SeaEngineRLAgent, SeaEngineRandomAgent
from RL_AI.SeaEngine.bridge.seaengine_session import SeaEngineSession
from RL_AI.simulation.evaluator import evaluate_agents
from RL_AI.training.reward import terminal_reward_for_player
from RL_AI.analysis.reports import build_win_rate_report
from RL_AI.rl_common.storage import RolloutBuffer, RolloutStep


@dataclass
class PPOConfig:
    learning_rate: float = 3e-4
    gamma: float = 0.99
    gae_lambda: float = 0.95
    clip_epsilon: float = 0.2
    value_loss_coef: float = 0.5
    entropy_coef: float = 0.05
    update_epochs: int = 4
    max_grad_norm: float = 0.5
    mini_batch_size: int = 64


class SeaEnginePPOTrainer:
    def __init__(self, agent: SeaEngineRLAgent, config: Optional[PPOConfig] = None) -> None:
        self.agent = agent
        self.config = PPOConfig() if config is None else config

    def _resolve_opponent_for_episode(
        self,
        episode_id: int,
        *,
        opponent_agent: Optional[SeaEngineAgent] = None,
        opponent_pool: Optional[Sequence[SeaEngineAgent]] = None,
        seed: Optional[int] = None,
    ) -> SeaEngineAgent:
        if opponent_pool:
            return random.choice(list(opponent_pool))
        if opponent_agent is not None:
            return opponent_agent
        return SeaEngineRandomAgent(seed=seed)

    def _maybe_add_self_play_snapshot(
        self,
        opponent_pool: list[SeaEngineAgent],
        *,
        update_count: int,
        snapshot_interval_updates: int,
        max_self_play_opponents: int,
        seed: Optional[int] = None,
    ) -> None:
        if snapshot_interval_updates <= 0 or max_self_play_opponents <= 0:
            return
        if update_count % snapshot_interval_updates != 0:
            return
        snapshot_name = f"selfplay_u{update_count}"
        snapshot_agent = self.agent.clone_as_opponent(
            name=snapshot_name,
            sample_actions=False,
            seed=seed,
        )
        opponent_pool.append(snapshot_agent)
        self_play_agents = [agent for agent in opponent_pool if agent.name.startswith("selfplay_")]
        overflow = len(self_play_agents) - max_self_play_opponents
        if overflow <= 0:
            return
        trimmed_pool: list[SeaEngineAgent] = []
        removed = 0
        for agent in opponent_pool:
            if removed < overflow and agent.name.startswith("selfplay_"):
                removed += 1
                continue
            trimmed_pool.append(agent)
        opponent_pool[:] = trimmed_pool

    def _extend_buffer(self, dst: RolloutBuffer, src: RolloutBuffer) -> None:
        for step in src.steps:
            dst.add_step(step)

    def _assign_terminal_rewards(self, buffer: RolloutBuffer, result: str) -> None:
        grouped = buffer.trajectory_groups()
        for (_, player_idx), indices in grouped.items():
            if not indices:
                continue
            player_id = "P1" if player_idx == 0 else "P2"
            terminal_reward = terminal_reward_for_player(result, player_id)
            last_index = indices[-1]
            for index in indices:
                buffer.steps[index].reward = 0.0
                buffer.steps[index].done = False
            buffer.steps[last_index].reward = terminal_reward
            buffer.steps[last_index].done = True

    def collect_episode(
        self,
        *,
        episode_id: int = 0,
        opponent_agent: Optional[SeaEngineAgent] = None,
        session: Optional[SeaEngineSession] = None,
        card_data_path: Optional[str] = None,
        player1_deck: str = "",
        player2_deck: str = "",
        max_turns: int = 100,
        learning_player_id: str = "P1",
    ) -> Dict[str, object]:
        owns_session = session is None
        if session is None:
            session = SeaEngineSession(card_data_path=card_data_path)
            session.start()
        try:
            snapshot = session.init_game(player1_deck=player1_deck, player2_deck=player2_deck)
            buffer = RolloutBuffer()
            opponent = opponent_agent if opponent_agent is not None else SeaEngineRandomAgent()
            steps = 0

            # Random/Greedy 상대는 auto_play_strategy 속성이 있음.
            # C# apply_auto를 사용해 IPC 호출을 절반으로 줄이는 고속 경로.
            # 자기 대전(selfplay) 상대는 NN 추론이 필요하므로 Python 경로 유지.
            opponent_auto_strategy: Optional[str] = getattr(opponent, "auto_play_strategy", None)

            while snapshot["result"] == "Ongoing" and snapshot["turn"] <= max_turns:
                legal_actions = snapshot.get("actions", [])
                if not legal_actions:
                    break

                acting_player = snapshot["active_player"]

                if acting_player == learning_player_id:
                    # RL 에이전트 턴
                    output = self.agent.compute_policy_output(snapshot, legal_actions)
                    buffer.add_step(
                        RolloutStep(
                            episode_id=episode_id,
                            player_id=0 if learning_player_id == "P1" else 1,
                            state_vector=output.state_vector,
                            action_feature_vectors=output.action_feature_vectors,
                            chosen_action_index=output.action_index,
                            reward=0.0,
                            done=False,
                            old_log_prob=output.log_prob,
                            old_value=output.value,
                        )
                    )
                    if opponent_auto_strategy is not None:
                        # 고속 경로: RL 행동 적용 + C#이 상대 턴을 자동 처리
                        snapshot = session.apply_and_auto_play(
                            action_uid=output.action["uid"],
                            learner_id=learning_player_id,
                            strategy=opponent_auto_strategy,
                        )
                        steps += 1
                    else:
                        # 기본 경로 (자기 대전 등): RL 행동만 적용
                        snapshot = session.apply_action(output.action["uid"])
                        steps += 1
                else:
                    # 상대 에이전트 턴 (자기 대전 또는 고속 경로 사용 불가 시)
                    _, action = choose_action_with_agent(opponent, snapshot)
                    snapshot = session.apply_action(action["uid"])
                    steps += 1

            self._assign_terminal_rewards(buffer, str(snapshot["result"]))
            buffer.compute_returns_and_advantages(self.config.gamma, self.config.gae_lambda)
            return {
                "buffer": buffer,
                "result": snapshot["result"],
                "steps": steps,
                "final_turn": snapshot["turn"],
            }
        finally:
            if owns_session:
                session.close()

    def update_from_buffer(self, buffer: RolloutBuffer) -> Dict[str, float]:
        if len(buffer) == 0:
            return {"policy_loss": 0.0, "value_loss": 0.0, "entropy": 0.0}

        if self.agent.optimizer is None:
            self.agent.ensure_model(state_dim=len(buffer.steps[0].state_vector))
        assert self.agent.optimizer is not None and self.agent.model is not None

        normalized_advantages = buffer.normalized_advantages()
        # advantage를 index로 접근할 수 있도록 리스트화
        adv_list: List[float] = list(normalized_advantages)

        policy_loss_total = 0.0
        value_loss_total = 0.0
        entropy_total = 0.0
        update_count = 0
        mini_batch_size = max(1, self.config.mini_batch_size)

        for _ in range(self.config.update_epochs):
            # 에포크마다 인덱스를 섞어 미니배치 다양성 확보
            indices = list(range(len(buffer.steps)))
            random.shuffle(indices)

            for batch_start in range(0, len(indices), mini_batch_size):
                batch_indices = indices[batch_start : batch_start + mini_batch_size]
                batch_size = len(batch_indices)

                batch_policy_loss = torch.zeros(1, device=self.agent.device)
                batch_value_loss = torch.zeros(1, device=self.agent.device)
                batch_entropy = torch.zeros(1, device=self.agent.device)

                for idx in batch_indices:
                    step = buffer.steps[idx]
                    norm_advantage = adv_list[idx]

                    old_log_prob = torch.tensor(step.old_log_prob, dtype=torch.float32, device=self.agent.device)
                    advantage = torch.tensor(norm_advantage, dtype=torch.float32, device=self.agent.device)
                    return_value = torch.tensor(step.return_value, dtype=torch.float32, device=self.agent.device)

                    log_prob, entropy, value = self.agent.evaluate_action_set(
                        step.state_vector,
                        step.action_feature_vectors,
                        step.chosen_action_index,
                    )

                    ratio = torch.exp(log_prob - old_log_prob)
                    clipped_ratio = torch.clamp(ratio, 1.0 - self.config.clip_epsilon, 1.0 + self.config.clip_epsilon)
                    policy_loss = -torch.min(ratio * advantage, clipped_ratio * advantage)
                    value_loss = (value - return_value).pow(2)

                    batch_policy_loss = batch_policy_loss + policy_loss
                    batch_value_loss = batch_value_loss + value_loss
                    batch_entropy = batch_entropy + entropy

                # 미니배치 평균 loss로 1회 업데이트
                loss = (
                    batch_policy_loss / batch_size
                    + self.config.value_loss_coef * batch_value_loss / batch_size
                    - self.config.entropy_coef * batch_entropy / batch_size
                )
                self.agent.optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_(self.agent.model.parameters(), self.config.max_grad_norm)
                self.agent.optimizer.step()

                policy_loss_total += float((batch_policy_loss / batch_size).item())
                value_loss_total += float((batch_value_loss / batch_size).item())
                entropy_total += float((batch_entropy / batch_size).item())
                update_count += 1

        return {
            "policy_loss": policy_loss_total / max(1, update_count),
            "value_loss": value_loss_total / max(1, update_count),
            "entropy": entropy_total / max(1, update_count),
        }

    def train(
        self,
        *,
        num_episodes: int,
        opponent_agent: Optional[SeaEngineAgent] = None,
        opponent_pool: Optional[Sequence[SeaEngineAgent]] = None,
        card_data_path: Optional[str] = None,
        player1_deck: str = "",
        player2_deck: str = "",
        max_turns: int = 100,
        update_interval: int = 8,
        self_play_snapshot_interval_updates: int = 0,
        max_self_play_opponents: int = 0,
        alternate_player_sides: bool = True,
        progress_callback: Optional[Callable[[int, int, str, Dict[str, object]], None]] = None,
    ) -> Dict[str, object]:
        active_opponent_pool = list(opponent_pool) if opponent_pool is not None else None
        results = {
            "episodes": 0,
            "wins": 0,
            "losses": 0,
            "draws": 0,
            "last_update": None,
            "updates": 0,
            "update_interval": update_interval,
            "opponents": [],
            "learning_as_p1": 0,
            "learning_as_p2": 0,
        }
        pending_buffer = RolloutBuffer()
        session = SeaEngineSession(card_data_path=card_data_path)
        session.start()
        try:
            for episode_id in range(num_episodes):
                learning_player_id = "P1" if (not alternate_player_sides or episode_id % 2 == 0) else "P2"
                selected_opponent = self._resolve_opponent_for_episode(
                    episode_id,
                    opponent_agent=opponent_agent,
                    opponent_pool=active_opponent_pool,
                )
                rollout = self.collect_episode(
                    episode_id=episode_id,
                    opponent_agent=selected_opponent,
                    session=session,
                    card_data_path=card_data_path,
                    player1_deck=player1_deck,
                    player2_deck=player2_deck,
                    max_turns=max_turns,
                    learning_player_id=learning_player_id,
                )
                result = str(rollout["result"])
                self._extend_buffer(pending_buffer, rollout["buffer"])

                results["episodes"] += 1
                if learning_player_id == "P1":
                    results["learning_as_p1"] += 1
                else:
                    results["learning_as_p2"] += 1
                if selected_opponent.name not in results["opponents"]:
                    results["opponents"].append(selected_opponent.name)
                if (learning_player_id == "P1" and result == "Player1Win") or (
                    learning_player_id == "P2" and result == "Player2Win"
                ):
                    results["wins"] += 1
                elif result in {"Player1Win", "Player2Win"}:
                    results["losses"] += 1
                else:
                    results["draws"] += 1

                if progress_callback is not None:
                    progress_callback(
                        results["episodes"],
                        num_episodes,
                        selected_opponent.name,
                        {
                            "result": result,
                            "wins": results["wins"],
                            "losses": results["losses"],
                            "draws": results["draws"],
                            "updates": results["updates"],
                            "learning_player_id": learning_player_id,
                        },
                    )

                should_update = len(pending_buffer) > 0 and (
                    results["episodes"] % max(1, update_interval) == 0 or episode_id == num_episodes - 1
                )
                if should_update:
                    results["last_update"] = self.update_from_buffer(pending_buffer)
                    results["updates"] += 1
                    pending_buffer.clear()
                    if active_opponent_pool is not None:
                        self._maybe_add_self_play_snapshot(
                            active_opponent_pool,
                            update_count=int(results["updates"]),
                            snapshot_interval_updates=self_play_snapshot_interval_updates,
                            max_self_play_opponents=max_self_play_opponents,
                        )
                    if progress_callback is not None:
                        progress_callback(
                            results["episodes"],
                            num_episodes,
                            selected_opponent.name,
                            {
                                "result": result,
                                "wins": results["wins"],
                                "losses": results["losses"],
                                "draws": results["draws"],
                                "updates": results["updates"],
                                "last_update": results["last_update"],
                                "learning_player_id": learning_player_id,
                            },
                        )
        finally:
            session.close()

        return results

    def build_default_opponent_pool(self, *, seed: Optional[int] = None) -> list[SeaEngineAgent]:
        return [
            SeaEngineRandomAgent(seed=seed),
            SeaEngineGreedyAgent(seed=None if seed is None else seed + 1),
            SeaEngineGreedyAgent(seed=None if seed is None else seed + 2),
        ]

    def evaluate(
        self,
        *,
        opponent_agent: Optional[SeaEngineAgent] = None,
        num_matches: int = 20,
        card_data_path: Optional[str] = None,
        player1_deck: str = "",
        player2_deck: str = "",
        max_turns: int = 100,
        progress_callback: Optional[Callable[[int, int, str, str], None]] = None,
    ) -> Dict[str, object]:
        opponent = SeaEngineRandomAgent() if opponent_agent is None else opponent_agent
        return evaluate_agents(
            self.agent,
            opponent,
            num_matches=num_matches,
            card_data_path=card_data_path,
            player1_deck=player1_deck,
            player2_deck=player2_deck,
            max_turns=max_turns,
            progress_callback=progress_callback,
        )

    def evaluate_report(
        self,
        *,
        opponent_agent: Optional[SeaEngineAgent] = None,
        num_matches: int = 20,
        card_data_path: Optional[str] = None,
        player1_deck: str = "",
        player2_deck: str = "",
        max_turns: int = 100,
    ) -> str:
        summary = self.evaluate(
            opponent_agent=opponent_agent,
            num_matches=num_matches,
            card_data_path=card_data_path,
            player1_deck=player1_deck,
            player2_deck=player2_deck,
            max_turns=max_turns,
        )
        return build_win_rate_report(summary)
